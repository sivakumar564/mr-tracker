import './globals.css';
export const metadata={title:'MyTrack | Personal Progress Tracker',description:'Academic, project, event and deadline tracker'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
